<div class="content">
    <h2>Vous êtes dans votre espace personnel !</h2>
    <a href="destroy.php">Déconnexion</a>
</div>